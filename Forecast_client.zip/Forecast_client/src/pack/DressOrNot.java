package pack;

public class DressOrNot extends WeatherLike {
	
	public DressOrNot(double tempCurrent, double tempHourly, double tempDaily) {
		super(tempCurrent, tempHourly, tempDaily);
		// TODO Auto-generated constructor stub
	}

	
}
