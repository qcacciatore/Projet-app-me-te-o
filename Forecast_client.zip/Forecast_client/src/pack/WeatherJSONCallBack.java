package pack;

public interface WeatherJSONCallBack {
public void onWeatherJSONRetrieveComplete(String json) throws Exception;
}
