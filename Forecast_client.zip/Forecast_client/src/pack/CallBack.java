package pack;


public interface CallBack {
public void onLoginComplete(boolean isLoginOk);
}
