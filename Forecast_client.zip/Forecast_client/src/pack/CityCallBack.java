package pack;

import java.util.ArrayList;

public interface CityCallBack {
	public void onCitiesRetrieveComplete(ArrayList<String> citiesList);
}
